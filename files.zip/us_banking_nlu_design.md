# US Banking NLU System Design — Complete Reference

A consolidated guide to building intent classification and entity extraction for a US retail banking assistant, covering prompting strategies, architectural patterns, the labeled dataset, and production recommendations.

---

## Table of Contents

1. [Overview](#1-overview)
2. [Quick Decision Framework](#2-quick-decision-framework)
3. [Prompting Approaches](#3-prompting-approaches)
   - 3.1 [Zero-Shot](#31-zero-shot)
   - 3.2 [Few-Shot with Examples](#32-few-shot-with-examples)
   - 3.3 [Schema-Defined (Strict)](#33-schema-defined-strict)
   - 3.4 [Chain-of-Thought](#34-chain-of-thought)
   - 3.5 [Hierarchical Intent](#35-hierarchical-intent)
   - 3.6 [Confidence-Calibrated](#36-confidence-calibrated)
4. [Dataset Reference](#4-dataset-reference)
   - 4.1 [Intent Registry](#41-intent-registry)
   - 4.2 [Entity Registry](#42-entity-registry)
   - 4.3 [Security Rules](#43-security-rules)
   - 4.4 [Example Record Structure](#44-example-record-structure)
5. [Architectural Patterns Beyond Prompting](#5-architectural-patterns-beyond-prompting)
   - 5.1 [RAG / Dynamic Few-Shot](#51-rag--dynamic-few-shot)
   - 5.2 [Embedding-Based Classifier](#52-embedding-based-classifier)
   - 5.3 [Hybrid Classifier + LLM Fallback](#53-hybrid-classifier--llm-fallback)
   - 5.4 [Function Calling / Tool Use](#54-function-calling--tool-use)
   - 5.5 [Database-Backed Slot Resolution](#55-database-backed-slot-resolution)
   - 5.6 [Fine-Tuning a Small Model](#56-fine-tuning-a-small-model)
   - 5.7 [Multi-Agent Router](#57-multi-agent-router)
   - 5.8 [Knowledge Graph / Ontology](#58-knowledge-graph--ontology)
   - 5.9 [Active Learning Loop](#59-active-learning-loop)
   - 5.10 [Semantic Caching](#510-semantic-caching)
6. [Production Recommendation](#6-production-recommendation)
7. [Evaluation](#7-evaluation)
8. [Augmentation Recipes](#8-augmentation-recipes)
9. [Appendix](#9-appendix)

---

## 1. Overview

Building a DialogFlow-style NLU system for US retail banking requires solving four problems: **intent classification** (what does the user want?), **entity extraction** (what parameters did they specify?), **slot resolution** (what do those parameters refer to in the user's actual data?), and **security gating** (don't capture SSN, PIN, OTP, CVV, or full PANs).

The naive solution is a single prompt to an LLM. That works for prototypes but breaks at scale on cost, latency, taxonomy size, and grounding. This document covers six prompting strategies for the prototype phase and ten architectural patterns for the production phase, with guidance on when to use each.

**US-specific design constraints:**

- Currency defaults to USD
- Payment rails: ACH, Wire, Zelle, Venmo, Cash App, Bill Pay, Check
- Account types: checking, savings, money_market, cd, hsa, ira
- Loan types: mortgage (15-yr / 30-yr / ARM), auto, personal, student, heloc
- Critical PII: SSN (XXX-XX-XXXX), full account/routing/card numbers
- Numbering: comma-thousands, `k` / `M` / `mil` abbreviations
- Dates default to MM/DD/YYYY when ambiguous

---

## 2. Quick Decision Framework

| Situation | Recommended approach |
|---|---|
| Prototype, fewer than 20 intents, no labeled data | Pure prompting — Approach 2 or 3 |
| 20–100 intents with labeled data | RAG (5.1) + database resolution (5.5) |
| High QPS, tight latency budget | Embedding classifier (5.2) + LLM for entities |
| Production at scale, cost-sensitive | Hybrid (5.3) + semantic caching (5.10) |
| Tight execution integration | Function calling (5.4) + database resolution (5.5) |
| 200+ intents across distinct domains | Multi-agent router (5.7) |
| Stable taxonomy, very high volume | Fine-tune (5.6) |
| Regulated, audit-heavy enterprise | Knowledge graph (5.8) + active learning (5.9) |

The realistic production stack typically combines four of these: function calling (5.4) for the LLM interface, RAG (5.1) for dynamic few-shot at scale, database-backed slot resolution (5.5) for grounding, and active learning (5.9) for the improvement loop.

---

## 3. Prompting Approaches

### 3.1 Zero-Shot

Quickest to set up. Useful when intents are open-ended or you're prototyping. Lower accuracy than any few-shot variant.

```text
You are an NLU module for a US retail banking assistant.

Identify per utterance:
1. INTENT — snake_case (check_balance, transfer_money, pay_bill,
   view_transactions, block_card, dispute_transaction, apply_loan,
   mobile_deposit, open_cd, check_credit_score, security_block, fallback)
2. ENTITIES — banking parameters
3. CONFIDENCE — 0.0 to 1.0

US BANKING CONTEXT:
- Currency defaults to USD
- Rails: ACH, Wire, Zelle (email/phone handle), Venmo (@handle),
  Cash App ($cashtag), Bill Pay, Check
- Account types: checking, savings, money_market, cd, hsa, ira
- Loan types: mortgage (15/30-yr), auto, personal, student, heloc
- Amount formats: $5,000 / $5k / $1.2M / "two hundred bucks"

SECURITY (non-negotiable):
- SSN pattern (XXX-XX-XXXX or 9-digit in SSN context)
  → intent="security_block"
- Full account/routing/card numbers → extract last 4 only, flag redact
- PIN, OTP, CVV, password → intent="security_block", confidence=1.0

Return JSON only:
{"intent": "<name>", "confidence": <float>,
 "entities": [{"name": "<n>", "type": "<t>", "value": <v>}],
 "redact_flags": [...]}

If no intent identifiable: intent="fallback", confidence<0.5.

Utterance: {user_input}
```

### 3.2 Few-Shot with Examples

Best general-purpose option for a fixed intent list. Examples anchor model behavior far more reliably than instructions alone.

```text
You are an NLU engine for a US RETAIL BANKING assistant.

Supported intents:
  check_balance, transfer_money, pay_bill, view_transactions,
  block_card, unblock_card, request_statement, apply_loan,
  check_loan_status, dispute_transaction, setup_autopay,
  cancel_autopay, open_cd, close_cd, mobile_deposit, order_checks,
  update_contact, raise_complaint, find_branch_atm,
  check_credit_score, security_block,
  greet, goodbye, thanks, affirm, deny, fallback

Entity types:
  account_last4, account_type [checking|savings|money_market|cd|hsa|ira],
  amount (USD by default), currency,
  beneficiary_name, beneficiary_account_last4,
  routing_number_last4, swift_code,
  transfer_type [ACH|WIRE|ZELLE|VENMO|CASH_APP|BILL_PAY|CHECK],
  zelle_handle (phone or email), venmo_handle, cashapp_handle,
  card_type [debit|credit], card_last4,
  card_network [visa|mastercard|amex|discover],
  date_range, date, transaction_id, merchant_name,
  bill_type [electric|gas|water|internet|phone|cable|credit_card|
             mortgage|insurance|hoa],
  biller_name, loan_type [mortgage|auto|personal|student|heloc|home_equity],
  loan_amount, tenure_months, apr,
  cd_amount, cd_tenure, statement_period, complaint_type, zip_code

SECURITY RULES (non-negotiable):
- SSN PATTERN (XXX-XX-XXXX or 9 consecutive digits in SSN context) →
  intent="security_block", set redact_flags=["ssn_detected"], NEVER echo.
- Full account / routing / card numbers → extract LAST 4 only,
  set redact_flags accordingly.
- PIN, OTP, CVV, password, security-question answers →
  intent="security_block", confidence=1.0.
- Amount normalization: "5k"=5000, "1.2M"=1200000, "$2.5K"=2500,
  "two hundred bucks"=200.

Return JSON only.

--- EXAMPLES ---

Utterance: "What's my checking balance?"
{"intent": "check_balance", "confidence": 0.98, "entities": [
  {"name": "account_type", "type": "account_type", "value": "checking"}]}

Utterance: "Zelle $50 to john@example.com"
{"intent": "transfer_money", "confidence": 0.98, "entities": [
  {"name": "amount", "type": "amount", "value": 50},
  {"name": "currency", "type": "currency", "value": "USD"},
  {"name": "handle", "type": "zelle_handle", "value": "john@example.com"},
  {"name": "rail", "type": "transfer_type", "value": "ZELLE"}]}

Utterance: "Wire $250,000 to my contractor, routing ends 4521, account ends 9988"
{"intent": "transfer_money", "confidence": 0.98, "entities": [
  {"name": "amount", "type": "amount", "value": 250000},
  {"name": "beneficiary", "type": "beneficiary_name", "value": "contractor"},
  {"name": "routing", "type": "routing_number_last4", "value": "4521"},
  {"name": "ben_acct", "type": "beneficiary_account_last4", "value": "9988"},
  {"name": "rail", "type": "transfer_type", "value": "WIRE"}]}

Utterance: "Venmo Sarah $30 for dinner"
{"intent": "transfer_money", "confidence": 0.97, "entities": [
  {"name": "amount", "type": "amount", "value": 30},
  {"name": "beneficiary", "type": "beneficiary_name", "value": "Sarah"},
  {"name": "rail", "type": "transfer_type", "value": "VENMO"},
  {"name": "memo", "type": "merchant_name", "value": "dinner"}]}

Utterance: "Pay my Con Edison electric bill, $142"
{"intent": "pay_bill", "confidence": 0.98, "entities": [
  {"name": "amount", "type": "amount", "value": 142},
  {"name": "bill_type", "type": "bill_type", "value": "electric"},
  {"name": "biller", "type": "biller_name", "value": "Con Edison"}]}

Utterance: "I want to apply for a 30-year mortgage of $450,000"
{"intent": "apply_loan", "confidence": 0.98, "entities": [
  {"name": "loan_type", "type": "loan_type", "value": "mortgage"},
  {"name": "loan_amount", "type": "loan_amount", "value": 450000},
  {"name": "tenure", "type": "tenure_months", "value": 360, "raw_text": "30-year"}]}

Utterance: "I see an $89 charge from Amazon on May 3rd I didn't make"
{"intent": "dispute_transaction", "confidence": 0.97, "entities": [
  {"name": "amount", "type": "amount", "value": 89},
  {"name": "merchant", "type": "merchant_name", "value": "Amazon"},
  {"name": "date", "type": "date", "value": "2026-05-03"}]}

Utterance: "My SSN is 123-45-6789, can you look up my account?"
{"intent": "security_block", "confidence": 1.0, "entities": [],
 "redact_flags": ["ssn_detected"],
 "response_hint": "Never accept SSN via chat. Route to verified authentication flow."}

Utterance: "What's my CVV?"
{"intent": "security_block", "confidence": 1.0, "entities": [],
 "response_hint": "Bank cannot disclose CVV; user must check their card."}

--- END EXAMPLES ---

Utterance: {user_input}
```

### 3.3 Schema-Defined (Strict)

Best for production. Forces output to a defined taxonomy, surfaces missing required slots, and signals when clarification is needed.

```text
You are an NLU module for US retail banking. Output matches the schema exactly.

=== INTENT_REGISTRY ===
check_balance:        required: []                       optional: [account_type, account_last4]
transfer_money:       required: [amount]                 optional: [beneficiary_name, ben_acct_last4, zelle_handle, venmo_handle, transfer_type, routing_number_last4]
pay_bill:             required: [bill_type]              optional: [amount, biller_name, account_last4]
view_transactions:    required: []                       optional: [date_range, account_last4, amount, merchant_name]
block_card:           required: [card_type]              optional: [card_last4, complaint_type]
request_statement:    required: [statement_period]       optional: [account_last4, format]
apply_loan:           required: [loan_type]              optional: [loan_amount, tenure_months, apr]
dispute_transaction:  required: []                       optional: [amount, date, transaction_id, merchant_name]
setup_autopay:        required: [bill_type, biller_name] optional: [amount, account_last4, frequency]
open_cd:              required: [cd_amount]              optional: [cd_tenure, apr]
mobile_deposit:       required: [amount]                 optional: [account_last4]
check_credit_score:   required: []                       optional: [bureau]
security_block:       required: []                       optional: []

=== OUTPUT ===
{
  "intent": "<from registry>",
  "confidence": <0.0-1.0>,
  "entities": [{"name": "<n>", "type": "<t>", "value": <v>, "raw_text": "<span>"}],
  "missing_required": ["<entity>", ...],
  "needs_clarification": <bool>,
  "redact_flags": ["ssn_detected" | "full_card" | "full_account" | "full_routing" | "cvv_provided"]
}

=== RULES ===
1. SSN (XXX-XX-XXXX or contextual 9-digit) → security_block, redact_flags=["ssn_detected"]
2. PIN/OTP/CVV/password → security_block, confidence=1.0
3. Full card/account/routing → extract last 4, set redact_flags
4. Amount normalization: $5k=5000, $1.2M=1200000, "two hundred bucks"=200
5. Date defaults: US format MM/DD/YYYY when ambiguous
6. Multi-intent: return as "intents": [...] array sorted by confidence

Utterance: {user_input}
```

### 3.4 Chain-of-Thought

Best for ambiguous or compositional utterances. Trades latency for accuracy. Useful as a teacher model when labeling data for a cheaper student.

```text
You are an NLU module for US retail banking. Reason before producing output.

For each utterance, reason through:
1. What is the user trying to do?
2. What banking entities are explicit (amount, beneficiary, rail, account, biller)?
3. What's implicit or ambiguous (rail choice, base amount, beneficiary identity)?
4. Any security-sensitive elements (SSN, full PAN, PIN/OTP/CVV)?
5. How confident am I, and why?

Wrap reasoning in <reasoning>, final answer in <answer>.

--- EXAMPLE ---

Utterance: "Send my regular rent to the landlord, but $50 less this time"

<reasoning>
1. Goal: a transfer to a known recurring beneficiary, with an amount modifier.
2. Explicit: beneficiary="landlord" (saved contact), modifier="$50 less".
3. "Regular rent" is implicit — base amount must be resolved from prior history.
   Rail unspecified — likely ACH given recurring nature.
4. No security concerns.
5. Medium confidence — depends on context lookup of prior rent amount.
</reasoning>
<answer>
{"intent": "transfer_money", "confidence": 0.75, "entities": [
  {"name": "beneficiary", "type": "beneficiary_name", "value": "landlord"},
  {"name": "amount_modifier", "type": "amount", "value": -50,
   "note": "delta vs base"}],
 "missing_required": ["base_amount"],
 "needs_clarification": true,
 "context_lookup_needed": ["last_rent_payment_amount"]}
</answer>

--- END EXAMPLE ---

Utterance: {user_input}
```

### 3.5 Hierarchical Intent

Useful when a flat taxonomy becomes unwieldy (50+ intents). Matches how real support taxonomies are structured. Allows short-circuiting at the head level when sub-level confidence is low.

```text
You are a hierarchical NLU classifier for US retail banking.

HEAD (domain):
  accounts, payments, cards, loans, investments, support, security

SUB (function under each head):
  accounts:    [check_balance, view_transactions, request_statement, update_contact]
  payments:    [transfer_money, pay_bill, setup_autopay, cancel_autopay,
                mobile_deposit, order_checks]
  cards:       [block_card, unblock_card, dispute_transaction, check_credit_score]
  loans:       [apply_loan, check_loan_status, refinance_loan]
  investments: [open_cd, close_cd, view_portfolio]
  support:     [raise_complaint, find_branch_atm, check_offers]
  security:    [security_block]

LEAF (specific action):
  transfer_money:      [zelle, venmo, cashapp, ach, wire, internal_transfer]
  pay_bill:            [credit_card, mortgage, utility, insurance, recurring]
  dispute_transaction: [duplicate, unauthorized, atm_failure, merchant_dispute]
  apply_loan:          [mortgage_purchase, mortgage_refi, auto, personal,
                        student_refi, heloc]

Return:
{
  "head": "<head>",
  "sub": "<sub or null>",
  "leaf": "<leaf or null>",
  "confidence": {"head": <f>, "sub": <f>, "leaf": <f>},
  "entities": [...],
  "needs_clarification": <bool>
}

Cascading rule: if confidence at any level < 0.6, set lower levels to null
and needs_clarification = true.

Utterance: {user_input}
```

### 3.6 Confidence-Calibrated

Best when the system should ask back instead of acting on shaky predictions. Combines cleanly with any of the above. High-value transfers and international wires always require confirmation regardless of confidence — these are policy gates, not ML decisions.

```text
You are an NLU module for US retail banking with calibrated uncertainty.

Return:
{
  "intent": "<intent or null>",
  "alternatives": [{"intent": "<i>", "confidence": <f>}, ...],   // top 3
  "entities": [...],
  "confidence": <float>,
  "action": "execute" | "confirm" | "clarify" | "fallback" | "security_block",
  "clarification_question": "<string or null>"
}

Decision policy:
  Security pattern (SSN, PIN, OTP, full PAN, password)        → "security_block"
  High-value transfer (>$10,000) regardless of confidence     → "confirm"
  International wire regardless of confidence                 → "confirm"
  confidence ≥ 0.85                                            → "execute"
  0.60 ≤ confidence < 0.85                                     → "confirm"
  0.40 ≤ confidence < 0.60                                     → "clarify"
  confidence < 0.40                                            → "fallback"

Calibration guidance:
- Lower confidence when required entities are missing
  (e.g., amount on transfer, biller on pay_bill, card_type on block_card)
- Lower confidence when beneficiary is name-only (no handle/account)
  — multiple "Mike"s in user's contacts
- Lower confidence with negation/hedging ("maybe", "don't", "actually")
- Lower confidence when amount uses ambiguous units ("a couple thousand")
- Surface multi-intent in "alternatives" rather than collapsing

Utterance: {user_input}
```

---

## 4. Dataset Reference

The companion file `us_banking_nlu_dataset.json` contains 131 labeled utterances across 28 intents. Structure summary:

### 4.1 Intent Registry

| Category | Intents |
|---|---|
| Accounts | `check_balance`, `view_transactions`, `request_statement`, `update_contact` |
| Payments | `transfer_money`, `pay_bill`, `setup_autopay`, `cancel_autopay`, `mobile_deposit`, `order_checks` |
| Cards | `block_card`, `unblock_card`, `dispute_transaction`, `check_credit_score` |
| Loans | `apply_loan`, `check_loan_status` |
| Investments | `open_cd`, `close_cd` |
| Support | `raise_complaint`, `find_branch_atm`, `check_offers` |
| Security | `security_block` |
| Social | `greet`, `goodbye`, `thanks`, `affirm`, `deny`, `fallback` |

### 4.2 Entity Registry

| Entity | Type | Notes |
|---|---|---|
| `account_last4` | string | 4 digits only — never store full |
| `account_type` | enum | checking, savings, money_market, cd, hsa, ira |
| `amount` | int or float | USD by default |
| `currency` | ISO 4217 | USD default; non-USD signals international wire |
| `beneficiary_name` | string | Free-form, resolved against saved contacts |
| `beneficiary_account_last4` | string | 4 digits |
| `routing_number_last4` | string | 4 digits — full routing is 9, never store all |
| `zelle_handle` | string | Email or US phone |
| `venmo_handle` | string | `@username` format |
| `cashapp_handle` | string | `$cashtag` format |
| `transfer_type` | enum | ACH, WIRE, ZELLE, VENMO, CASH_APP, BILL_PAY, CHECK |
| `card_type` | enum | debit, credit |
| `card_last4` | string | 4 digits |
| `card_network` | enum | visa, mastercard, amex, discover |
| `bill_type` | enum | electric, gas, water, internet, phone, cable, credit_card, mortgage, insurance, hoa |
| `biller_name` | string | Free-form (Con Edison, PG&E, Verizon, etc.) |
| `loan_type` | enum | mortgage, auto, personal, student, heloc, home_equity, business |
| `loan_amount`, `tenure_months`, `apr` | numeric | Loan parameters |
| `cd_amount`, `cd_tenure` | numeric, string | CD parameters |
| `statement_period` | enum | last_month, last_3_months, ytd, tax_year, custom |
| `date_range`, `date` | ISO | Use MM/DD interpretation when ambiguous |
| `transaction_id`, `merchant_name` | string | For dispute/lookup flows |
| `zip_code` | string | 5 or 9 digits |
| `bureau` | enum | experian, equifax, transunion (for credit score) |

### 4.3 Security Rules

1. **SSN detection.** Patterns `XXX-XX-XXXX`, `XXX XX XXXX`, or 9 consecutive digits in SSN context → `security_block` intent with `redact_flags: ["ssn_detected"]`. Never echo, log, or store.
2. **PIN, OTP, CVV, password, security-question answers** → `security_block`, confidence 1.0. Treat as a precision-critical class (target ~100% precision).
3. **Full account, routing, or card numbers** → extract last 4 only, set the corresponding `redact_flags` entry, scrub from logs.
4. **Read-back attacks.** "Read me the OTP you just sent" is a known phishing vector and must be refused.

### 4.4 Example Record Structure

```json
{
  "id": "TXN-007",
  "utterance": "Wire $250,000 to my contractor, routing ends 4521, account ends 9988",
  "intent": "transfer_money",
  "confidence": 0.98,
  "entities": [
    {"name": "amount", "type": "amount", "value": 250000},
    {"name": "beneficiary", "type": "beneficiary_name", "value": "contractor"},
    {"name": "routing", "type": "routing_number_last4", "value": "4521"},
    {"name": "ben_acct", "type": "beneficiary_account_last4", "value": "9988"},
    {"name": "rail", "type": "transfer_type", "value": "WIRE"}
  ],
  "priority": "high",
  "notes": "High-value wire — additional auth required."
}
```

Multi-intent utterances use an `intents: [...]` array instead of a single `intent` field. Security-sensitive examples carry a `redact_flags` array. Spanish-language examples carry `lang: "es"`.

---

## 5. Architectural Patterns Beyond Prompting

Prompts alone scale poorly past ~20 intents and have no way to ground beneficiary names, billers, or account references against the user's actual data. Production banking NLU systems combine several of the patterns below.

### 5.1 RAG / Dynamic Few-Shot

Index the labeled dataset in a vector database (pgvector, Pinecone, Weaviate, Qdrant). At runtime, embed the incoming utterance, retrieve the top-k nearest neighbors, and inject them as few-shot examples in the prompt.

```python
def classify(utterance: str) -> dict:
    query_emb = embed(utterance)                  # ~50ms
    neighbors = vector_db.search(query_emb, k=8)  # ~20ms
    prompt = build_prompt(utterance, examples=neighbors)
    return llm.complete(prompt)                   # ~300ms
```

**Why it works:** scales to thousands of intents, examples are always relevant to the specific utterance, adding a new intent means inserting rows in the DB — no prompt edits, no retraining. Prompt size stays small, which lowers cost per call.

**Use when:** 50+ intents or a sizable labeled corpus, and you can run an embedding service.

### 5.2 Embedding-Based Classifier

Embed every utterance, train a lightweight classifier (logistic regression, KNN, or a fine-tuned sentence-transformer head). Intent classification becomes a vector lookup in single-digit milliseconds. Use the LLM only for entity extraction with an intent-specific prompt.

```
utterance → embedding → classifier → intent (5ms)
                                  ↓
                  LLM with intent-specific entity schema (200ms)
                                  ↓
                            structured output
```

**Use when:** high QPS, well-defined intent taxonomy, tight latency budget. Trades recall on novel phrasings for 10–100x cost reduction.

### 5.3 Hybrid Classifier + LLM Fallback

The pragmatic production architecture. Classifier handles confident cases (score ≥ 0.85); LLM only runs for low-confidence or ambiguous utterances. Roughly 80–90% of traffic skips the LLM entirely.

**Use when:** production scale where cost matters. This is how most large deployments are actually built.

### 5.4 Function Calling / Tool Use

Define each intent as a tool with a strict JSON schema for its entities. The LLM picks a tool and fills its parameters; the schema is enforced by the API rather than by your parser. This is the closest modern equivalent to DialogFlow's intent + parameter model.

```python
tools = [
    {
        "name": "transfer_money",
        "description": "Send money via Zelle, Venmo, ACH, or Wire",
        "input_schema": {
            "type": "object",
            "properties": {
                "amount":      {"type": "number"},
                "beneficiary": {"type": "string"},
                "rail":        {"type": "string",
                                "enum": ["ZELLE", "VENMO", "CASH_APP", "ACH", "WIRE"]},
                "handle":      {"type": "string"},
                "account_last4": {"type": "string", "pattern": "^[0-9]{4}$"},
            },
            "required": ["amount"]
        }
    },
    {"name": "check_balance", "input_schema": {"type": "object", "properties": {...}}},
    # ... one tool per intent
]
```

**Use when:** type safety and execution integration matter. Drawback: provider lock-in to a specific tool-spec format.

### 5.5 Database-Backed Slot Resolution

The missing piece in pure-LLM setups. When a user says "send $500 to Mike," the LLM extracts `beneficiary="Mike"` — but "Mike" isn't an account, it's a label. Resolve it against the user's saved beneficiaries. Same for billers, accounts, and previously-used handles.

```python
def resolve_entities(intent, entities, user_id):
    if intent == "transfer_money" and "beneficiary" in entities:
        candidates = db.beneficiaries.search(user_id, name=entities["beneficiary"])
        if len(candidates) == 1:
            entities["beneficiary_account_last4"] = candidates[0].account_last4
            entities["beneficiary_resolved"] = True
        elif len(candidates) > 1:
            entities["needs_disambiguation"] = candidates  # ask user
    return entities
```

This isn't optional for production banking — it's table stakes. Without it, every transfer requires re-asking for account details the user has already saved.

**Use when:** always, in production. Pair with any of the prompting or model approaches.

### 5.6 Fine-Tuning a Small Model

Fine-tune Haiku, Llama-3-8B, or a similar small model on the labeled dataset. Once trained, it's cheap, fast, and specialized — and can run locally if compliance demands.

**Use when:** stable taxonomy (not adding intents weekly), high volume, and at least 500–1000 examples per intent. The base dataset is below that bar; use the augmentation recipes in Section 8 to reach the threshold.

### 5.7 Multi-Agent Router

A small fast router model classifies the head domain (`payments` vs `cards` vs `loans`) in single-digit milliseconds. Each domain has a specialist NLU agent with a tight, domain-specific prompt and tool set. Specialists never see vocabulary or intents from other domains, so each prompt stays small and accurate.

```
User → Router (Haiku, head intent) → routes to:
                                      ├─ Payments specialist (Sonnet)
                                      ├─ Cards specialist (Sonnet)
                                      ├─ Loans specialist (Sonnet)
                                      └─ Support specialist (Haiku)
```

**Use when:** very large taxonomy (200+ intents), distinct domain teams, or compliance reasons to isolate domains. Mitigate router-as-single-point-of-failure by falling back to a generalist agent on low router confidence.

### 5.8 Knowledge Graph / Ontology

Model the constraints: "transfer to mortgage" is only valid if the user has a mortgage account; "Zelle to John" requires John to have a Zelle-enrolled handle. The ontology rules out nonsensical resolutions that pure ML would otherwise accept.

**Use when:** enterprise systems with strong consistency requirements. Heavy upfront modeling cost; usually overkill below ~$10M ARR.

### 5.9 Active Learning Loop

Production logs every low-confidence prediction (say, 0.4–0.7) to a queue for human labeling. Labeled examples feed back into the vector DB (5.1) or training set (5.6) on a weekly cycle. Catches distribution drift — new merchants, new slang, new fraud patterns.

**Use when:** production with an annotation team. Not a starting architecture, but it's how systems stay accurate over time.

### 5.10 Semantic Caching

Cache classifications by embedding similarity. If today's utterance is within 0.95 cosine similarity of one classified last week, return the cached result — no LLM call. For banking, where utterances cluster heavily ("check my balance" is said a million times a day), this can cut LLM cost 40–60%.

---

## 6. Production Recommendation

A realistic production architecture for a US retail banking NLU system, in execution order:

```
User utterance
     │
     ▼
┌──────────────────────────────────────────┐
│ 1. Preprocessing                          │
│    - amount normalization ($5k → 5000)    │
│    - SSN regex pretrip                    │
│    - full-PAN/routing/account detection   │
└──────────────────────────────────────────┘
     │
     ▼
┌──────────────────────────────────────────┐
│ 2. Semantic cache lookup (5.10)           │
│    Hit (≥0.95 cosine) → return cached     │
└──────────────────────────────────────────┘
     │ miss
     ▼
┌──────────────────────────────────────────┐
│ 3. Embedding classifier (5.2)             │
│    Confident (≥0.85) → use predicted      │
│                         intent directly   │
└──────────────────────────────────────────┘
     │ low confidence
     ▼
┌──────────────────────────────────────────┐
│ 4. RAG + LLM with function calling        │
│    (5.1 + 5.4)                            │
│    - Retrieve top-8 nearest examples      │
│    - Call LLM with tool schema            │
│    - Returns structured intent + entities │
└──────────────────────────────────────────┘
     │
     ▼
┌──────────────────────────────────────────┐
│ 5. Database slot resolution (5.5)         │
│    - Resolve beneficiary against contacts │
│    - Resolve biller against saved payees  │
│    - Mark needs_disambiguation if needed  │
└──────────────────────────────────────────┘
     │
     ▼
┌──────────────────────────────────────────┐
│ 6. Policy gates                           │
│    - High-value (>$10k) → require confirm │
│    - International wire → require confirm │
│    - Security pattern → block             │
└──────────────────────────────────────────┘
     │
     ▼
┌──────────────────────────────────────────┐
│ 7. Logging                                │
│    - Redact PII per redact_flags          │
│    - Queue low-confidence for active      │
│      learning (5.9)                       │
└──────────────────────────────────────────┘
     │
     ▼
   Action
```

**Why this stack:** the cache and classifier handle the vast majority of traffic at low cost and low latency. RAG + function calling handles the long tail with high accuracy. Database resolution provides the grounding that pure prompting can't. Policy gates enforce business rules separately from ML decisions. Active learning closes the loop.

---

## 7. Evaluation

### Splits

70% train / 15% dev / 15% test, stratified by intent. Ensure security-critical examples (SSN, PIN, OTP) are distributed evenly across splits — clustering them in test only inflates the apparent SSN-redaction-recall metric.

### Required Metrics

| Metric | Target | Why |
|---|---|---|
| Intent accuracy | ≥ 0.92 | Core NLU quality |
| Entity precision/recall/F1 per type | ≥ 0.88 | Per-slot quality |
| Joint accuracy (intent + all entities correct) | ≥ 0.80 | What the user actually experiences |
| Expected calibration error (ECE) | ≤ 0.05 | Confidence scores match reality |
| Fallback recall (OOS detection) | ≥ 0.85 | Don't hallucinate intents |
| **Security block precision** | **≥ 0.99** | False negatives are catastrophic |
| **SSN redaction recall** | **≥ 0.99** | Same |
| Multi-intent F1 (where applicable) | ≥ 0.75 | Compound utterances |

### Edge-Case Buckets Required for Coverage

Every release should be evaluated on these buckets separately, not just on the aggregate test set:

- Negation ("don't transfer", "I did NOT authorize")
- Multi-intent ("check balance and pay electric")
- Spanish-English ("transferir 500 dólares a Maria")
- Ambiguous single-token ("money", "account", "help")
- US-numbering with commas ($1,234.56)
- Abbreviations and SMS shorthand (`chkg`, `acct`, `txns 4m last wk`)
- Security: PIN, OTP, CVV, SSN (multiple SSN formats)
- Full-vs-last-4 numbers (full routing redaction)
- Frequency expressions (biweekly, monthly, every Friday)
- P2P handles (Zelle email/phone, Venmo `@`, Cash App `$`)

### Adversarial Sets

Maintain separate adversarial test sets that don't feed into training:

- **SSN-disclosure paraphrases** — 50+ ways users phrase SSN sharing
- **PIN/OTP read-back attempts** — social-engineering patterns
- **High-value transfer obfuscation** — "send everything I have to..."
- **Prompt injection in beneficiary names** — `"; DROP TABLE`, embedded instructions

---

## 8. Augmentation Recipes

The base dataset (131 examples) is below the 500–1000-per-intent threshold needed for fine-tuning. Scale it using:

1. **Paraphrase expansion.** Generate 3–5 paraphrases per utterance using Sonnet or Opus at temperature 0.7. Roughly 5x expansion.
2. **Entity-value swapping.** Swap entity values from pools: US first names, billers (PG&E, Con Edison, Spectrum, Verizon, AT&T, Comcast, Chase, Wells Fargo, BoA), US ZIPs, US-format phones, realistic dollar amounts ($1–$10M). 10x expansion.
3. **Typo and shorthand injection.** Add typos and SMS shorthand at 5–10% character corruption rate. Improves robustness to mobile input.
4. **Spanish variants.** Generate Spanish versions of the top-50 utterances. ~13% of US households speak Spanish at home.
5. **Adversarial SSN set.** Generate 50+ phrasings of SSN disclosure: "my social is...", "last 4 of my SSN is...", "123 45 6789", "social security: ...". Test redaction robustness.
6. **Adversarial security set.** Phrase password/PIN/OTP requests innocently ("I forgot, can you just remind me of..."). Test refusal robustness.

Combined, these recipes get the dataset from 131 examples to ~5,000+ — enough to fine-tune a small model.

---

## 9. Appendix

### A. Common US Billers (for entity-value pools)

**Electric / Gas / Water:** Con Edison, PG&E, Duke Energy, Florida Power & Light, Dominion Energy, Southern Company, National Grid, ComEd, NIPSCO, Xcel Energy

**Telecom:** Verizon, AT&T, T-Mobile, Comcast Xfinity, Spectrum, Cox, CenturyLink, Frontier, Optimum

**Credit cards:** Chase, Amex, Capital One, Citi, Discover, Bank of America, Wells Fargo, US Bank, Synchrony, Barclays

**Insurance:** State Farm, Geico, Progressive, Allstate, Liberty Mutual, USAA, Farmers

### B. Common US Banks (for entity-value pools)

JPMorgan Chase, Bank of America, Wells Fargo, Citibank, US Bank, PNC, Truist, Capital One, TD Bank, Goldman Sachs (Marcus), Charles Schwab Bank, Ally, Discover Bank, SoFi, Chime

### C. Amount Normalization Reference

| Input | Normalized |
|---|---|
| `$5,000` | `5000` |
| `$5k` | `5000` |
| `$5K` | `5000` |
| `$1.2M` | `1200000` |
| `$1.5 mil` | `1500000` |
| `five hundred dollars` | `500` |
| `two hundred bucks` | `200` |
| `$1,234.56` | `1234.56` |
| `1.5 grand` | `1500` |

### D. Date Parsing Reference

| Input | Resolved (assuming today = 2026-05-11) |
|---|---|
| `4/15` | `2026-04-15` |
| `4/15/26` | `2026-04-15` |
| `April 15` | `2026-04-15` |
| `yesterday` | `2026-05-10` |
| `last Friday` | `2026-05-08` |
| `last month` | `{start: 2026-04-01, end: 2026-04-30}` |
| `last 3 months` | `{start: 2026-02-11, end: 2026-05-11}` |
| `YTD` | `{start: 2026-01-01, end: 2026-05-11}` |
| `tax year 2025` | `{start: 2025-01-01, end: 2025-12-31}` |
| `the 1st` (in transfer context) | next occurrence of the 1st |

### E. Companion Files

- `us_banking_nlu_dataset.json` — 131 labeled utterances, schema, eval suggestions, augmentation recipes

---

*End of document.*
