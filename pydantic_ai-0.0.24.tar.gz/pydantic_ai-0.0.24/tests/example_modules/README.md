# docs examples imports

This directory is added to `sys.path` in `tests/test_examples.py::test_docs_examples` to augment some of the examples.
